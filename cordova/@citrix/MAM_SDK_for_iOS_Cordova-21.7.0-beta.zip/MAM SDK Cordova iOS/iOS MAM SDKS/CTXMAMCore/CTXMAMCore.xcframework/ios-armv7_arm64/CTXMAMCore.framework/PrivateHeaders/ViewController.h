//
//  ViewController.h
//  CTXMAMCoreUnitTestApp
//
//  Created by Daniel Romano on 6/20/19.
//  Copyright © 2019 Citrix Systems, Inc. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

