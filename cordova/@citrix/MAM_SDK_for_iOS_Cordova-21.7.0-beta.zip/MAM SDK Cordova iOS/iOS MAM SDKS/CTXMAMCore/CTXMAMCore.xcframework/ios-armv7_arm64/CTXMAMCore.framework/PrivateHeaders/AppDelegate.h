//
//  AppDelegate.h
//  CTXMAMCoreUnitTestApp
//
//  Created by Daniel Romano on 6/20/19.
//  Copyright © 2019 Citrix Systems, Inc. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;
@property (nonatomic, copy) NSDictionary* myLaunchOptions;

@end

