//
//  ObscureViewController.h
//  CTXMAMContainment
//
//  Created by David Hoy on 5/6/14.
//  Copyright © 2014 - 2019 Citrix Systems, Inc. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ObscureViewController : UIViewController

@end
