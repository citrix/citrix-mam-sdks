var app = {
    // Application Constructor
initialize: function() {
    document.addEventListener('deviceready', this.onDeviceReady.bind(this), false);
},

onDeviceReady: function() {
    this.receivedEvent('deviceready');
    
    // -- Core Plugin --
    let {core} = cordova.plugins.citrix;
    let {localauth} = cordova.plugins.citrix;
    let {containment} = cordova.plugins.citrix;
    let {compliance} = cordova.plugins.citrix;
    let {network} = cordova.plugins.citrix;
    //Pass the Plugin objects as parameters as shown in example below to initialize the respective plugins
    core.initializeSDKs(onInitializeSDKsSuccess, onInitializeSDKsError, localauth, containment, compliance, network);
    // Optional APIs
    core.registerProxyServerSettingDetected(onProxyServerSettingDetected);
    core.registerSdksInitializedAndReady(onSdksInitializedAndReady);
    //    Parameters
    //    config - A string object which describes the data being saved.
    //    defaultValue - The value to be saved in the secure storage.
    //    error - An out parameter where an error is saved in case one occurs.
    core.setConfigurationForStringKey('KeyConfig', 'defaultValue', onSetConfigurationForStringKeySuccess, onSetConfigurationForStringKeyFailure);
    
    //Parameters
    //config - A string object which describes the saved data.
    //defaultValue - The value to be returned in case the specified configuration is not found in the secure storage.
   core.getConfigurationAsStringForKey('KeyConfig', 'defaultValue',onGetConfigurationAsStringForKeySuccess, onGetConfigurationAsStringForKeyFailure);
    
    // -- Local Auth Plugin --
    // Optional APIs
    // Calling these APIs means that the user is willing to add custom implementation for the callbacks. If not implemented, Plugin will take the default actions.
    localauth.registerDevicePasscodeRequired(onDevicePasscodeRequired);
    localauth.registerMaxOfflinePeriodWillExceedWarning(onMaxOfflinePeriodWillExceedWarning);
    localauth.registerMaxOfflinePeriodExceeded(onMaxOfflinePeriodExceeded);


    // -- Containment Plugin --
    // Optional APIs
    // Calling these APIs means that the user is willing to add custom implementation for the callbacks. If not implemented, Plugin will take the default actions.
    containment.registerAppIsOutsideGeofencingBoundary(onAppIsOutsideGeofencingBoundary);
    containment.registerAppNeedsLocationServicesEnabled(onAppNeedsLocationServicesEnabled);
    
    // Compliance Plugin APIs
    // Optional Delegates Implementations
    // Calling these APIs means that user is adding custom implementation for the delegate callbacks.
    compliance.registerAdminLockAppSecurityActionForError(onAdminLockAppSecurityActionForError);
    compliance.registerDevicePasscodeComplianceViolationForError(onDevicePasscodeComplianceViolationForError);
    compliance.registerAdminWipeAppSecurityActionForError(onAdminWipeAppSecurityActionForError);
    compliance.registerContainerSelfDestructSecurityActionForError(onContainerSelfDestructSecurityActionForError);
    compliance.registerAppDisabledSecurityActionForError(onAppDisabledSecurityActionForError);
    compliance.registerDateAndTimeChangeSecurityActionForError(onDateAndTimeChangeSecurityActionForError);
    compliance.registerUserChangeSecurityActionForError(onUserChangeSecurityActionForError);
    compliance.registerDevicePasscodeComplianceViolationForError(onDevicePasscodeComplianceViolationForError);
    compliance.registerJailbreakComplianceViolationForError(onJailbreakComplianceViolationForError);
    compliance.registerEDPComplianceViolationForError(onEDPComplianceViolationForError);

    // Network Plugin Test
   this.testInAppBrowser();
   this.testFetch();

},

receivedEvent: function(id) {
    let parentElement = document.getElementById(id);
    let listeningElement = parentElement.querySelector('.listening');
    let receivedElement = parentElement.querySelector('.received');

    listeningElement.setAttribute('style', 'display:none;');
    receivedElement.setAttribute('style', 'display:block;');
    console.log('Received Event: ' + id);
},
 
// Test containment Plugin
openCamera: function () {

    var onSuccess = function(imageData) {
      var image = document.getElementById('cameraImage');
        image.src = "data:image/jpeg;base64," + imageData;
        image.width = "100";
        image.height = "100";
   };

   var onFail = function(message) {
    alert('Failed because: ' + message);
   };
    
   navigator.camera.getPicture(onSuccess, onFail, {
      quality: 50,
      sourceType: Camera.PictureSourceType.CAMERA,
      destinationType: Camera.DestinationType.DATA_URL
   });
},

openGallery: function () {
    var onSuccess = function(imageData) {
      var image = document.getElementById('galleryImage');
        image.src = "data:image/jpeg;base64," + imageData;
        image.width = "100";
        image.height = "100";
   };

   var onFail = function(message) {
    alert('Failed because: ' + message);
   };
    
   navigator.camera.getPicture(onSuccess, onFail, {
      quality: 50,
      sourceType: Camera.PictureSourceType.PHOTOLIBRARY,
      destinationType: Camera.DestinationType.DATA_URL
   });
},
    
sendSms: function() {
    var number = document.getElementById('numberTxt').value.toString(); /* iOS: ensure number is actually a string */
    var message = document.getElementById('messageTxt').value;
    console.log("number=" + number + ", message= " + message);

    //CONFIGURATION
    var options = {
        replaceLineBreaks: false, // true to replace \n by a new line, false by default
    };

    var success = function () { alert('Message sent successfully'); };
    var error = function (e) { alert('Message Failed:' + e); };
    sms.send(number, message, options, success, error);
},
    
testGeo: function() {
    var onSuccess = function(position) {
    alert('Latitude: '          + position.coords.latitude          + '\n' +
          'Longitude: '         + position.coords.longitude         + '\n' +
          'Altitude: '          + position.coords.altitude          + '\n' +
          'Accuracy: '          + position.coords.accuracy          + '\n' +
          'Altitude Accuracy: ' + position.coords.altitudeAccuracy  + '\n' +
          'Heading: '           + position.coords.heading           + '\n' +
          'Speed: '             + position.coords.speed             + '\n' +
          'Timestamp: '         + position.timestamp                + '\n');
    };

    var onError = function(error) {
        alert('code: '    + error.code    + '\n' +
              'message: ' + error.message + '\n');
    };

   navigator.geolocation.getCurrentPosition(onSuccess, onError);
},

testiFrame: function() {
    let parentElement = document.getElementById('testBase');
    let iframe = document.createElement('iframe');
    iframe.src = 'http://google.com';
    iframe.height = '25%'
    iframe.width = '90%'
    parentElement.appendChild(iframe);
},

testFetch: function() {
    console.log('inside cordova fetch trye');
    cordovaFetch('https://www.googleapis.com/customsearch/v1')
        .then(function(response) {
            console.log('received json response');
            return response.json();
        })
        .then(function(json) {
            console.log('received json: ' + json);
         }) 
        .catch(err => {
            console.log('error getting text from response: ' + err);
        })
    },
    
// Test containment Plugin
testInAppBrowser: function() {
    window.open = cordova.InAppBrowser.open('http://google.com', '_blank', 'location=yes');
    },
};

app.initialize();

// -- Callbacks for CITRIX Core Plugin --
function onInitializeSDKsSuccess() {
    /* User can perform logging or any other action as required. */
}

function onInitializeSDKsFailure() {
    /* An error dict will be returned containing error code and error info. */
}

function onProxyServerSettingDetected() {
    /* User can perform logging or any other action as required. */
}

function onSdksInitializedAndReady() {
    /* User can perform logging or any other action as required. */
}

function onSetConfigurationForStringKeySuccess() {
    /* User can perform logging or any other action as required. */
}

function onSetConfigurationForStringKeyFailure() {
    /* An error dict will be returned containing error code and error info. */
}

function onGetConfigurationAsStringForKeySuccess(){
    /* User can perform logging or any other action as required. */
}

function onGetConfigurationAsStringForKeyFailure(){
    /* An error dict will be returned containing error code and error info. */
}

// -- Callbacks for CITRIX Local Auth Plugin --
function onDevicePasscodeRequired() {
    // Notify user
}
function onMaxOfflinePeriodWillExceedWarning(secondsToExpire) {
    // The variable "secondsToExpire" contains the number of seconds left for the max offline period will exceed.
    // Notify user with the secondsToExpire
}
function onMaxOfflinePeriodExceeded() {
    // Notify user
}

// -- Callbacks for CITRIX Containment Plugin --
function onAppIsOutsideGeofencingBoundary() {
    // Notify user
}
function onAppNeedsLocationServicesEnabled() {
    // Notify user
}

/* Callback for Compliance Delegates*/
function onAdminLockAppSecurityActionForError(complianceError) {
    /* Callback implementation. For sample purposes only. User can choose to provide their own implmentation.*/
    alert('ErrorCode:' + complianceError['errorCode'] + ' UserInfoMsg:' + complianceError['userInfoMsg']);
    /* performLogonWithErrorContext is a Citrix Compiance SDK API, to perform logon. Takes errorCode as an input parameter. This example is just to demonstrate the usuage of performLogonWithErrorContext API. */
    cordova.plugins.citrix.compliance.performLogonWithErrorContext(complianceError['errorCode'] ,onPerformLogonWithErrorContext);
}

function onDevicePasscodeComplianceViolationForError(complianceError) {
    /* Callback implementation. For sample purposes only. User can choose to provide their own implmentation.*/
    alert('ErrorCode:' + complianceError['errorCode'] + ' UserInfoMsg:' + complianceError['userInfoMsg']);
    /* performLogonWithErrorContext is a Citrix Compiance SDK API, to perform logon. Takes errorCode as an input parameter. This example is just to demonstrate the usuage of performLogonWithErrorContext API.*/
    cordova.plugins.citrix.compliance.performLogonWithErrorContext(complianceError['errorCode'] ,onPerformLogonWithErrorContext);
}

function onPerformLogonWithErrorContext(performCallbackResult) {
    /* Callback implementation. For sample purposes only. User can choose to provide their own implmentation.*/
    console.log(performCallbackResult);
    /* checkComplianceErrors is a Citrix Compiance SDK API. On invocation, this will throw a list of all the compliance errors on device/app. This example is just to demonstrate the usuage of checkComplianceErrors API. */
    cordova.plugins.citrix.compliance.checkComplianceErrors(onCheckComplianceErrors);
}

function onCheckComplianceErrors(complianceErrorList) {
    /* Callback implementation. For sample purposes only. User can choose to provide their own implmentation.*/
    alert(complianceErrorList);
}

function onAdminWipeAppSecurityActionForError(complianceError) {
    /* Callback implementation. For sample purposes only. User can choose to provide their own implmentation.*/
    alert('ErrorCode:' + complianceError['errorCode'] + ' UserInfoMsg:' + complianceError['userInfoMsg']);
    /* performLogonWithErrorContext is a Citrix Compiance SDK API, to perform logon. Takes errorCode as an input parameter. This example is just to demonstrate the usuage of performLogonWithErrorContext API.*/
    cordova.plugins.citrix.compliance.performLogonWithErrorContext(complianceError['errorCode'] ,onPerformLogonWithErrorContext);
}

function onContainerSelfDestructSecurityActionForError(complianceError) {
    /* Callback implementation. For sample purposes only. User can choose to provide their own implmentation.*/
    alert('ErrorCode:' + complianceError['errorCode'] + ' UserInfoMsg:' + complianceError['userInfoMsg']);
    /* performLogonWithErrorContext is a Citrix Compiance SDK API, to perform logon. Takes errorCode as an input parameter. This example is just to demonstrate the usuage of performLogonWithErrorContext API.*/
    cordova.plugins.citrix.compliance.performLogonWithErrorContext(complianceError['errorCode'] ,onPerformLogonWithErrorContext);
}

function onAppDisabledSecurityActionForError(complianceError) {
    /* Callback implementation. For sample purposes only. User can choose to provide their own implmentation.*/
    alert('ErrorCode:' + complianceError['errorCode'] + ' UserInfoMsg:' + complianceError['userInfoMsg']);
    /* performLogonWithErrorContext is a Citrix Compiance SDK API, to perform logon. Takes errorCode as an input parameter. This example is just to demonstrate the usuage of performLogonWithErrorContext API.*/
    cordova.plugins.citrix.compliance.performLogonWithErrorContext(complianceError['errorCode'] ,onPerformLogonWithErrorContext);
}

function onDateAndTimeChangeSecurityActionForError(complianceError) {
    /* Callback implementation. For sample purposes only. User can choose to provide their own implmentation.*/
    alert('ErrorCode:' + complianceError['errorCode'] + ' UserInfoMsg:' + complianceError['userInfoMsg']);
    /* performLogonWithErrorContext is a Citrix Compiance SDK API, to perform logon. Takes errorCode as an input parameter. This example is just to demonstrate the usuage of performLogonWithErrorContext API.*/
    cordova.plugins.citrix.compliance.performLogonWithErrorContext(complianceError['errorCode'] ,onPerformLogonWithErrorContext);
}

function onUserChangeSecurityActionForError(complianceError) {
    /* Callback implementation. For sample purposes only. User can choose to provide their own implmentation.*/
    alert('ErrorCode:' + complianceError['errorCode'] + ' UserInfoMsg:' + complianceError['userInfoMsg']);
    /* performLogonWithErrorContext is a Citrix Compiance SDK API, to perform logon. Takes errorCode as an input parameter. This example is just to demonstrate the usuage of performLogonWithErrorContext API.*/
    cordova.plugins.citrix.compliance.performLogonWithErrorContext(complianceError['errorCode'] ,onPerformLogonWithErrorContext);
}

function onDevicePasscodeComplianceViolationForError(complianceError) {
    /* Callback implementation. For sample purposes only. User can choose to provide their own implmentation.*/
    alert('ErrorCode:' + complianceError['errorCode'] + ' UserInfoMsg:' + complianceError['userInfoMsg']);
    /* performLogonWithErrorContext is a Citrix Compiance SDK API, to perform logon. Takes errorCode as an input parameter. This example is just to demonstrate the usuage of performLogonWithErrorContext API.*/
    cordova.plugins.citrix.compliance.performLogonWithErrorContext(complianceError['errorCode'] ,onPerformLogonWithErrorContext);
}

function onJailbreakComplianceViolationForError(complianceError) {/* Callback implementation. For sample purposes only. User can choose to provide their own implmentation.*/
    alert('ErrorCode:' + complianceError['errorCode'] + ' UserInfoMsg:' + complianceError['userInfoMsg']);
    /* performLogonWithErrorContext is a Citrix Compiance SDK API, to perform logon. Takes errorCode as an input parameter. This example is just to demonstrate the usuage of performLogonWithErrorContext API.*/
    cordova.plugins.citrix.compliance.performLogonWithErrorContext(complianceError['errorCode'] ,onPerformLogonWithErrorContext);
    
}

function onEDPComplianceViolationForError(complianceError) {
    /* Callback implementation. For sample purposes only. User can choose to provide their own implmentation.*/
    alert('ErrorCode:' + complianceError['errorCode'] + ' UserInfoMsg:' + complianceError['userInfoMsg']);
    /* performLogonWithErrorContext is a Citrix Compiance SDK API, to perform logon. Takes errorCode as an input parameter. This example is just to demonstrate the usuage of performLogonWithErrorContext API.*/
    cordova.plugins.citrix.compliance.performLogonWithErrorContext(complianceError['errorCode'] ,onPerformLogonWithErrorContext);
}



