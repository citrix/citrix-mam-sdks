//
//  CTXMAMAgentAppConstants.h
//  CtxSingleSignOn
//
//  Created by Jaspreet Singh on 5/20/15.
//
//  Copyright © 2015 - 2019 Citrix Systems, Inc. All rights reserved.
//

#ifndef CtxSingleSignOn_CTXMAMAgentAppConstants_h
#define CtxSingleSignOn_CTXMAMAgentAppConstants_h

//#define BIND_OBF_FILENAME_WH "4g1a7r2y7w0h6b7a7r7t0o0n"
//#define BIND_OBF_FILENAME_X1 "2j1a3s3p0x010r1e3e8t"

#endif
