//
//  CTXMAMAppCore.h
//  CTXMAMAppCore
//
//  Created by Daniel Romano on 4/22/20.
//  Copyright © 2020 Daniel Romano. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for CTXMAMAppCore.
FOUNDATION_EXPORT double CTXMAMAppCoreVersionNumber;

//! Project version string for CTXMAMAppCore.
FOUNDATION_EXPORT const unsigned char CTXMAMAppCoreVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <CTXMAMAppCore/PublicHeader.h>

@interface CTXMAMAppCore : NSObject

@end
