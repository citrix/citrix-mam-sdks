//
//  CTXMAMAppCore.h
//  CTXMAMAppCore
//
//  Citrix iOS MAM SDK Public Header
//  Copyright © 2020-2021 Citrix Systems, Inc. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for CTXMAMAppCore.
FOUNDATION_EXPORT double CTXMAMAppCoreVersionNumber;

//! Project version string for CTXMAMAppCore.
FOUNDATION_EXPORT const unsigned char CTXMAMAppCoreVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <CTXMAMAppCore/PublicHeader.h>

@interface CTXMAMAppCore : NSObject

/*!
 *  @brief This API performs a logon in Secure Hub.   Can be called to ensure that the user is logged on and prompt for a logon if not.
 *  @param completionBlock Completion block with the status of the logon request.  Argument success is set to YES if already logged on or logging on was successful.
 */
+(void) performLogon:(void(^ _Nullable)(BOOL success))completionBlock;


@end
