//
//  CTXMAMAppCore.h
//  CTXMAMAppCore
//
//  Citrix iOS MAM SDK Public Header
//  Copyright © 2020-2021 Citrix Systems, Inc. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for CTXMAMAppCore.
FOUNDATION_EXPORT double CTXMAMAppCoreVersionNumber;

//! Project version string for CTXMAMAppCore.
FOUNDATION_EXPORT const unsigned char CTXMAMAppCoreVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <CTXMAMAppCore/PublicHeader.h>

@interface CTXMAMAppCore : NSObject

@end
