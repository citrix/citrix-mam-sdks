/*
 * Copyright (c) 2023. Cloud Software Group, Inc. All Rights Reserved. Confidential & Proprietary.
 */

package com.citrix.mvpntestapp;

import android.app.Application;
import android.os.StrictMode;

import com.citrix.sdk.appcore.api.MamSdk;

public class MvpnCemTestApplication extends Application {

    @Override
    public void onCreate() {
        super.onCreate();

        // init MamSdk so that we don't crash
        MamSdk.initialize(this, null);

        if (BuildConfig.DEBUG) {
            StrictMode.setThreadPolicy(new StrictMode.ThreadPolicy.Builder()
                    .detectNetwork()   // detects N/W access on UI thread.
                    .permitDiskReads()
                    .permitDiskWrites()
                    .penaltyLog()
                    .penaltyDialog()
                    .build());

            StrictMode.setVmPolicy(new StrictMode.VmPolicy.Builder().detectAll().build());
        }
    }
}
