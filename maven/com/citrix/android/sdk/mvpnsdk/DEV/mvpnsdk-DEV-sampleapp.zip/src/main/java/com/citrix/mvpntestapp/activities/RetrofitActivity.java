/*
 * Copyright (c) 2023. Cloud Software Group, Inc. All Rights Reserved. Confidential & Proprietary.
 */

package com.citrix.mvpntestapp.activities;

import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.text.Html;
import android.util.Log;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.citrix.mvpn.api.MicroVPNSDK;
import com.citrix.mvpn.exception.MvpnException;
import com.citrix.mvpntestapp.R;
import com.citrix.sdk.logging.api.Logger;
import com.google.gson.Gson;

import net.minidev.json.JSONObject;

import java.io.IOException;
import java.lang.ref.WeakReference;
import java.util.HashMap;
import java.util.Map;

import okhttp3.FormBody;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Retrofit;
import retrofit2.http.Body;
import retrofit2.http.Field;
import retrofit2.http.FieldMap;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.Path;

public class RetrofitActivity extends AppCompatActivity {
    private static final Logger logger = Logger.getLogger("RetrofitActivity");
    private static final String TAG = "RetrofitActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.test_okhttp);

        new RetrofitAsyncTask(this).execute(getIntent().getStringExtra(MainActivity.URL_KEY));
    }

    private void displayResponse(String responseHtml) {
        TextView textView = findViewById(R.id.okHttpTextViewId);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            textView.setText(Html.fromHtml(responseHtml, Html.FROM_HTML_MODE_COMPACT));
        } else {
            textView.setText(Html.fromHtml(responseHtml));
        }
    }

    private static class RetrofitAsyncTask extends AsyncTask<String, Void, String> {
        private static final String LOG_TAG = "MVPN-RetrofitAsyncTask";

        private WeakReference<RetrofitActivity> reference;

        private RetrofitAsyncTask(RetrofitActivity activity) {
            reference = new WeakReference<>(activity);
        }

        private RetrofitActivity getActivity() {
            if (reference != null) {
                return reference.get();
            }
            return null;
        }

        @Override
        protected String doInBackground(String... strUrl) {
            RetrofitActivity activity = getActivity();
            OkHttpClient client = new OkHttpClient.Builder().build();
            try {
                client = (OkHttpClient) MicroVPNSDK.enableOkHttpClientObjectForNetworkTunnel(activity, client);
            } catch (MvpnException e) {
                logger.error(e.getMessage());
            }
            Retrofit retrofit = new Retrofit.Builder()
                    .baseUrl(strUrl[0])
                    .client(client)
                    .build();
            TestService service = retrofit.create(TestService.class);
            Map<String, Object> map = new HashMap<>();
            map.put("name", "test1");
            map.put("sex", "male");
            UserInfoBean userInfoBean = new UserInfoBean("test2", "female");
            RequestBody body = FormBody.create(MediaType.parse("application/json; charset=utf-8"), new Gson().toJson(userInfoBean));
            Call<ResponseBody> responseBody = service.getPostData2(body);
            responseBody.enqueue(new Callback() {
                @Override
                public void onResponse(Call call, retrofit2.Response response) {
                    Log.i(TAG,"onResponse:" + response.toString());
                    ResponseBody body = (ResponseBody) response.body();
                    try {
                        if (body != null) {
                            Log.i(TAG,"onResponse :" + body.string());
                        } else {
                            Log.i(TAG,"onResponse is null" );
                        }

                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }

                @Override
                public void onFailure(Call call, Throwable t) {
                    Log.d(TAG, "onFailure:" );
                    if (t != null) {
                        t.printStackTrace();
                    }
                }
            });


            return "";
        }

        @Override
        protected void onPostExecute(String responseHtml) {
            RetrofitActivity activity = getActivity();

            if (activity != null && !activity.isFinishing()) {
                activity.displayResponse(responseHtml);
            }
        }
    }

    public interface TestService {
        @GET("/")
        Call<ResponseBody> listSource();

        @FormUrlEncoded
        @POST("/")
        Call<ResponseBody> getPostData(@Field("name") String nameStr, @Field("sex") String sexStr);

        @FormUrlEncoded
        @POST("/")
        Call<ResponseBody> getPostData1(@FieldMap Map<String, Object> map);

        @POST("/")
        Call<ResponseBody> getPostData2(@Body RequestBody body);
    }
    public static class UserInfoBean {
        public String name;
        public String sex;

        public UserInfoBean(String n, String s) {
            name = n;
            sex = s;
        }
    }
}
