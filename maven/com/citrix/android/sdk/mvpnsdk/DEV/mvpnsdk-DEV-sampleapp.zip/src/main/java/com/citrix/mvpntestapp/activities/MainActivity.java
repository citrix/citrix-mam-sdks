/*
 * Copyright (c) 2023. Cloud Software Group, Inc. All Rights Reserved. Confidential & Proprietary.
 */
package com.citrix.mvpntestapp.activities;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.citrix.mvpn.api.MicroVPNSDK;
import com.citrix.mvpn.api.MvpnDefaultHandler;
import com.citrix.mvpn.helper.AnalyticsHelper;
import com.citrix.mvpntestapp.R;
import com.citrix.mvpntestapp.util.TunnelHandler;
import com.citrix.mvpntestapp.util.UrlUtil;
import com.citrix.mvpntestapp.util.VpnUtil;
import com.citrix.sdk.appcore.api.MamSdk;
import com.citrix.sdk.featureflag.api.FeatureFlagAPI;
import com.citrix.sdk.featureflag.model.FeatureFlagConstants;
import com.citrix.sdk.featureflag.model.FeatureFlagStatus;

import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends AppCompatActivity implements TunnelHandler.Callback {

    public static final String INTUNE_COMPANY_PORTAL_SELECTED_KEY = "INTUNE_COMPANY_PORTAL_SELECTED";

    private EditText uriText;

    private MvpnDefaultHandler mvpnHandler;

    public static final String URL_KEY = "URL";

    private boolean isIntuneSelected;

    private View progressBar;

    private static final int DEFAULT_RETRY_COUNT = 3;

    private static int retryCount = DEFAULT_RETRY_COUNT;

    public static TextView stat;

    private CheckBox ffCheckBox;

    private final ExecutorService executor = Executors.newSingleThreadExecutor();

    private static final String TEST_GOOGLE_ANALYTICS_LABEL = "MAMSDK_TestUploadGoogleAnalytice";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        isIntuneSelected = getIntent().getBooleanExtra(INTUNE_COMPANY_PORTAL_SELECTED_KEY, false);

        uriText = findViewById(R.id.inputURL);
        uriText.setText(UrlUtil.getSavedUrl(this));
        uriText.setSelection(uriText.getText().length());
        progressBar = findViewById(R.id.progressBar);
        stat = findViewById(R.id.status);
        ffCheckBox = findViewById(R.id.checkBox);
        Map<String, FeatureFlagStatus> flags = FeatureFlagAPI.getFeatureFlags(this);
        FeatureFlagStatus flagStatus = flags.get(FeatureFlagConstants.ANDROID_MAMSDK_MITM_NATIVE_HTTP);
        ffCheckBox.setChecked(flagStatus == FeatureFlagStatus.ENABLED);
    }

    private boolean errorCheck() {
        if (!MicroVPNSDK.isNetworkTunnelRunning(this)) {
            stat.setText("Tunnel is not running");
            return true;
        }
        return false;
    }

    public void onWebViewClicked(View view) {
        stat.setText("Status");
        if (!errorCheck()) {
            startActivity(createIntentWithUrl(WebViewActivity.class));
        }
    }

    public void onURLConnectionClicked(View view) {
        stat.setText("Status");
        if (!errorCheck()) {
            startActivity(createIntentWithUrl(UrlConnectionActivity.class));
        }
    }

    public void onOkHttpClicked(View view) {
        stat.setText("Status");
        if (!errorCheck()) {
            startActivity(createIntentWithUrl(OkHttpActivity.class));
        }
    }

    public void onStartTunnelClicked(View view) {
        stat.setText("Status");
        if (mvpnHandler == null) {
            mvpnHandler = new TunnelHandler(this);
        }
        if (VpnUtil.startTunnel(this, mvpnHandler, isIntuneSelected)) {
            progressBar.setVisibility(View.VISIBLE);
        } else {
            stat.setText("Tunnel is not started");
        }
    }

    public void onTunnelStatus(View view) {
        stat.setText("Status");
        if (!errorCheck()) {
            if (MicroVPNSDK.isNetworkTunnelRunning(this)) {
                stat.setText("Tunnel is running");
            } else {
                stat.setText("Tunnel is not running");
            }
        }
    }

    public void onStopTunnelClicked(View view) {
        stat.setText("Status");
        MicroVPNSDK.stopTunnel(this);
        int messageId = !MicroVPNSDK.isNetworkTunnelRunning(this) ? R.string.stop_tunnel_success_message : R.string.stop_tunnel_failed_message;
        stat.setText(getResources().getString(messageId));
    }

    public void onRefreshFeatureFlagsClicked(View view) {
        progressBar.setVisibility(View.VISIBLE);
        MamSdk mamSdk = MamSdk.getInstance(this, null);
        executor.execute(() -> {
            mamSdk.refreshFeatureFlags(this);
            Map<String, FeatureFlagStatus> newFlags = FeatureFlagAPI.getFeatureFlags(this);
            FeatureFlagStatus newFlagStatus = newFlags.get(FeatureFlagConstants.ANDROID_MAMSDK_MITM_NATIVE_HTTP);
            runOnUiThread(() -> {
                ffCheckBox.setChecked(newFlagStatus == FeatureFlagStatus.ENABLED);
                progressBar.setVisibility(View.GONE);
                stat.setText("Feature Flags Refreshed Successfully.");
            });
        });
    }

    public void uploadGoogleAnalyticsClicked(View view) {
        // init mamsdk
        MamSdk mamSdk = MamSdk.getInstance(this, null);
        // add toast
        String alertMsg = "GA Data: category=" + AnalyticsHelper.CATEGORY_MAM + ", action=" + TEST_GOOGLE_ANALYTICS_LABEL;
        AnalyticsHelper.logEvent(AnalyticsHelper.CATEGORY_MAM, TEST_GOOGLE_ANALYTICS_LABEL, new Bundle());
        new AlertDialog.Builder(this)
                .setTitle("")
                .setMessage(alertMsg)
                .setPositiveButton("ok", null)
                .show();
    }

    public void onCompanyPortalClicked(View view) {
        stat.setText("Status");
        if (MamSdk.getInstance(this, null) == null) {
            Toast.makeText(this, "Failed Intune Client", Toast.LENGTH_LONG).show();
        } else {
            Intent intent = new Intent(this, IntuneMAMEnrollmentActivity.class);
            startActivityForResult(intent, 0);
        }
    }

    private Intent createIntentWithUrl(Class<?> cls) {
        Intent intent = new Intent(this, cls);

        if (uriText.getText() != null && !TextUtils.isEmpty(uriText.getText().toString())) {
            String url = uriText.getText().toString();
            intent.putExtra(URL_KEY, url);
            UrlUtil.saveUrl(this, url);
        } else {
            intent.putExtra(URL_KEY, getString(R.string.test_uri));
        }
        return intent;
    }

    @Override
    public void onTunnelStarted() {
        runOnUiThread(() -> {
            retryCount = DEFAULT_RETRY_COUNT;
            progressBar.setVisibility(View.GONE);
            stat.setText(getResources().getString(R.string.start_tunnel_success_message));
        });
    }

    @Override
    public void onError(boolean isSessionExpired) {
        runOnUiThread(() -> {
            progressBar.setVisibility(View.GONE);
            if (isSessionExpired && retryCount-- > 0) {
                if (VpnUtil.startTunnel(this, mvpnHandler, isIntuneSelected)) {
                    stat.setText(getResources().getString(R.string.session_expired_message));
                } else {
                    stat.setText(getResources().getString(R.string.start_tunnel_failed_message));
                }
            } else {
                stat.setText(getResources().getString(R.string.start_tunnel_failed_message));
            }
        });
    }
}