package com.citrix.mvpntestapp;

import android.os.StrictMode;

import com.citrix.sdk.appcore.api.MamSdkArgs;
import com.microsoft.intune.mam.client.app.MAMApplication;

import com.citrix.sdk.appcore.api.MamSdk;

public class MvpnIntuneTestApplication extends MAMApplication {
    private static final String TAG = "MvpnIntuneTestApplication";

    public static MamSdk mamSdk;

    @Override
    public void onMAMCreate() {
        super.onMAMCreate();

        MamSdk.initialize(this, null);

        if (BuildConfig.DEBUG) {
            StrictMode.setThreadPolicy(new StrictMode.ThreadPolicy.Builder()
                    .detectNetwork()   // detects N/W access on UI thread.
                    .permitDiskReads()
                    .permitDiskWrites()
                    .penaltyLog()
                    .penaltyDialog()
                    .build());

            StrictMode.setVmPolicy(new StrictMode.VmPolicy.Builder().detectAll().build());
        }
    }
}
