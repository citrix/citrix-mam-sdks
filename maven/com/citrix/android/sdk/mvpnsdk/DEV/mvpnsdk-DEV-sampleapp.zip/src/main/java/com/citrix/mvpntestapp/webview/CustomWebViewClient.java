package com.citrix.mvpntestapp.webview;

import android.graphics.Bitmap;
import android.webkit.HttpAuthHandler;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import com.citrix.mvpntestapp.activities.MainActivity;
import com.citrix.sdk.logging.api.Logger;

public class CustomWebViewClient extends WebViewClient {
    private final Logger logger = Logger.getLogger("CustomWebViewClient");

    @Override
    public void onPageStarted(WebView view, String url, Bitmap favicon) {
        logger.debug5("WebViewClient onPageStarted:" + url);
    }

    @Override
    public void onPageFinished(WebView view, String url) {
        logger.debug5("WebViewClient onPageFinished:" + url);
        if (MainActivity.stat == null) {
            logger.debug5("Status label was null.");
            return;
        }
        //if there was no error, then it must be successful
        //note that onPageFinished gets called regardless of whether there is an error or not
        if (!MainActivity.stat.getText().equals("Web view failed")) {
            MainActivity.stat.setText("Web view successful");
        }
    }

    @Override
    public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
        int errorCode = error.getErrorCode();
        //if resource load was canceled by Safe Browsing, then this should not count as a failure
        if (errorCode != ERROR_UNSAFE_RESOURCE){
            if (MainActivity.stat != null) {
                MainActivity.stat.setText("Web view failed");
            }
            Toast.makeText(view.getContext(), error.getDescription(), Toast.LENGTH_SHORT).show();
        }
        super.onReceivedError(view, request, error);
    }

    public void onReceivedHttpAuthRequest(WebView view, HttpAuthHandler handler, String host, String realm)
    {
        logger.debug5("WebViewClient onReceivedHttpAuthRequest: " + "host: " + host + " realm: " + realm);
    }
}
