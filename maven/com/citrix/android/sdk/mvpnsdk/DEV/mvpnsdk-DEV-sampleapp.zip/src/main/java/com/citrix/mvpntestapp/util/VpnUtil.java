/*
 * Copyright (c) 2023. Cloud Software Group, Inc. All Rights Reserved. Confidential & Proprietary.
 */

package com.citrix.mvpntestapp.util;

import android.app.Activity;
import android.os.Handler;
import android.os.Messenger;

import com.citrix.mvpn.api.MicroVPNSDK;
import com.citrix.mvpntestapp.intune.IntuneAuthInfo;
import com.citrix.sdk.appcore.api.MamSdk;
import com.citrix.sdk.logging.api.Logger;

import java.util.List;
import java.util.Map;

public class VpnUtil {
    private static final String TAG = "Mvpn-VpnUtil";
    private static Logger logger = Logger.getLogger(TAG);
    private static final String OIDC_REDIRECT_URI = "ctxmvpntestoidc://oidc-longlivedtoken/login";
    public static boolean startTunnel(Activity activity, Handler handler, boolean isIntuneSelected) {
        logger.info("Starting Micro VPN Tunnel....");

        try
        {
            if (isIntuneSelected)
            {
                List<Map<String, String>> appConfig = IntuneAuthInfo.getInstance().getAppConfigFullData();
                String accessToken = IntuneAuthInfo.getInstance().getAccessToken();
                MicroVPNSDK.startTunnel(activity, new Messenger(handler), appConfig, accessToken);
            }
            else
            {
                MamSdk.initialize(activity, null);
                MamSdk mamSdk = MamSdk.getInstance(activity, null);
                MamSdk.OidcConfig oidcConfig = MamSdk.OidcConfig.builder().redirectURI(OIDC_REDIRECT_URI).build();
                mamSdk.setOidcConfiguration(activity, oidcConfig);
                MicroVPNSDK.startTunnel(activity, new Messenger(handler));
            }

            return true;
        } catch (Exception e) {
            logger.error("Failed to start tunnel: " + e.getMessage());
        }

        return false;
    }
}
